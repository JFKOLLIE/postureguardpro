<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>create-payment-intent.js - Netlify Function</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-6">
        <div class="flex items-center mb-6">
            <i class="fas fa-code text-blue-600 text-2xl mr-3"></i>
            <h1 class="text-2xl font-bold text-gray-800">create-payment-intent.js</h1>
        </div>
        
        <div class="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6">
            <div class="flex">
                <i class="fas fa-info-circle text-blue-400 mt-1 mr-2"></i>
                <div>
                    <p class="text-blue-800 font-semibold">Netlify Function File</p>
                    <p class="text-blue-700 text-sm">Save this as: netlify/functions/create-payment-intent.js</p>
                </div>
            </div>
        </div>

        <div class="bg-gray-900 rounded-lg p-4 overflow-x-auto">
            <pre class="text-green-400 text-sm"><code>const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event, context) => {
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  // Handle preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: '',
    };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' }),
    };
  }

  try {
    const { amount, currency = 'usd', customerInfo } = JSON.parse(event.body);

    // Validate input
    if (!amount || amount < 50) { // Minimum $0.50
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid amount' }),
      };
    }

    // Create payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // Convert to cents
      currency: currency,
      metadata: {
        product: 'PostureGuard Pro',
        customer_name: customerInfo?.name || '',
        customer_email: customerInfo?.email || '',
        customer_phone: customerInfo?.phone || '',
        shipping_address: JSON.stringify(customerInfo?.address || {}),
        order_date: new Date().toISOString(),
      },
      receipt_email: customerInfo?.email || null,
      shipping: customerInfo?.address ? {
        name: customerInfo.name,
        address: {
          line1: customerInfo.address.line1,
          line2: customerInfo.address.line2 || null,
          city: customerInfo.address.city,
          state: customerInfo.address.state,
          postal_code: customerInfo.address.postal_code,
          country: customerInfo.address.country || 'US',
        },
      } : null,
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id,
      }),
    };

  } catch (error) {
    console.error('Payment intent creation failed:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Payment processing failed',
        message: error.message 
      }),
    };
  }
};</code></pre>
        </div>

        <div class="mt-6 space-y-4">
            <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                <div class="flex">
                    <i class="fas fa-exclamation-triangle text-yellow-400 mt-1 mr-2"></i>
                    <div>
                        <p class="text-yellow-800 font-semibold">Environment Variables Required</p>
                        <p class="text-yellow-700 text-sm">Set STRIPE_SECRET_KEY in your Netlify environment variables</p>
                    </div>
                </div>
            </div>

            <div class="bg-green-50 border-l-4 border-green-400 p-4">
                <div class="flex">
                    <i class="fas fa-check-circle text-green-400 mt-1 mr-2"></i>
                    <div>
                        <p class="text-green-800 font-semibold">Features Included</p>
                        <ul class="text-green-700 text-sm mt-1 space-y-1">
                            <li>• CORS headers for frontend communication</li>
                            <li>• Payment intent creation with customer metadata</li>
                            <li>• Error handling and validation</li>
                            <li>• Shipping address collection</li>
                            <li>• Receipt email integration</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-6">
            <button onclick="copyCode()" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded flex items-center">
                <i class="fas fa-copy mr-2"></i>
                Copy Code
            </button>
        </div>
    </div>

    <script>
        function copyCode() {
            const code = document.querySelector('code').textContent;
            navigator.clipboard.writeText(code).then(() => {
                alert('Code copied to clipboard!');
            });
        }
    </script>
</body>
</html>
    <script id="html_badge_script1">
        window.__genspark_remove_badge_link = "https://www.genspark.ai/api/html_badge/" +
            "remove_badge?token=To%2FBnjzloZ3UfQdcSaYfDrJDWbZdVnqVb4k0rpHkljYO6nSJG3ddbvsJCWlznSJDk6Vup2HaUxLuYUoQxwQrqISia2ESlGGV6iEP4q84f%2Bxdeu%2BZbFPdF0rSCVUQaaq4Gm%2F3T8l6cjwfwJ8RSSxjrpCWyJdc7%2B%2BN%2BNlGNaJEkA2p8hj6k%2FJMBUESm4f6fNfJ6Vv8kMKdY4%2BLTJT0mdRDAoXUNacik6ccQlxSFXMXKOKlY61DR3B%2F3aFP9DyO9Ngx3ONwjKXeSrCNspqCVVSB5aZPu9SA%2FKijV%2F923EH90%2BQt4IbMFtWCXr9cNoIy%2BId1szmfLZ8wsMzfoN1iKm1VFKIFGobsnOocK4pSVw8fBUibaQ8op%2F%2FBtW%2FPAfYRU%2FqtgicF%2Bt8k1O16RAZ9U%2FmxRpc3Ht42aV7QaplvRtJgzTd57NfdkIV75gpyCkcn5P%2BdVOEgOMpgRH0jC0S6jv5CX%2BO%2FRGn53cBgqb0RMfvArwVS2HE6cnSBmwWY%2FLKsnffKnHJSbN4FE2l%2F4TZKSbDz7w%3D%3D";
        window.__genspark_locale = "en-US";
        window.__genspark_token = "To/BnjzloZ3UfQdcSaYfDrJDWbZdVnqVb4k0rpHkljYO6nSJG3ddbvsJCWlznSJDk6Vup2HaUxLuYUoQxwQrqISia2ESlGGV6iEP4q84f+xdeu+ZbFPdF0rSCVUQaaq4Gm/3T8l6cjwfwJ8RSSxjrpCWyJdc7++N+NlGNaJEkA2p8hj6k/JMBUESm4f6fNfJ6Vv8kMKdY4+LTJT0mdRDAoXUNacik6ccQlxSFXMXKOKlY61DR3B/3aFP9DyO9Ngx3ONwjKXeSrCNspqCVVSB5aZPu9SA/KijV/923EH90+Qt4IbMFtWCXr9cNoIy+Id1szmfLZ8wsMzfoN1iKm1VFKIFGobsnOocK4pSVw8fBUibaQ8op//BtW/PAfYRU/qtgicF+t8k1O16RAZ9U/mxRpc3Ht42aV7QaplvRtJgzTd57NfdkIV75gpyCkcn5P+dVOEgOMpgRH0jC0S6jv5CX+O/RGn53cBgqb0RMfvArwVS2HE6cnSBmwWY/LKsnffKnHJSbN4FE2l/4TZKSbDz7w==";
    </script>
    
    <script id="html_notice_dialog_script" src="https://www.genspark.ai/notice_dialog.js"></script>
    